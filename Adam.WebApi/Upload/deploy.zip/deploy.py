#!/usr/bin/python
# -*- coding: utf-8 -*-
import shutil
import os
import sys
import xml.etree.ElementTree as ET

def paraReplacer(path, paraDsatCon, paraEneityCon ):
        #path = "D:\\test.config"
        with open(path, "r") as f:
           data = f.read()
           #replace  DsatCon
           str = data.replace("@@DsatCon@@", paraDsatCon)
           #replace  TodoCon 
        #    str = str.replace("@@TodoCon@@", paraList[1])
           #replace  EneityCon 
           str = str.replace("@@EneityCon@@", paraEneityCon)

           with open(path, "w") as f:
                 f.write(str)

def main():
    configPath = sys.argv[1]
    tree = ET.parse(configPath)

    root = tree.getroot()

    # props
    originalFilePath = root.find("originalFilePath").text
    DestinationfilePath = root.find("DestinationfilePath").text
    webconfigPath = root.find("webconfigPath").text
    DsatPwd = root.find("DsatPwd").text
    EneityPwd = root.find("EneityPwd").text
    # EneityPwd = root.find("EneityPwd").text

    print('running.....')

    # comf1 = "cd " + originalFilePath
    # res = os.popen(comf1)
    # res.read()
    # print('cd originalFilePath done')

    # comfp5 = "echo %CD%"
    # res = os.popen(comfp5)
    # res.read()
    # print(os.get_exec_path())
    # print('cur path')

    com0 = "cd " + originalFilePath +  " && git pull"
    res = os.popen(com0)
    res.read()
    print('git pull done ' + com0)

    # command 1
    com1 = "xcopy " + originalFilePath + " " + DestinationfilePath + " /s/e/i/y"
    res = os.popen(com1)
    res.read()
    print('xcopy done' + com1)

    # com2 = "cd " + DestinationfilePath
    # res = os.popen(com2)
    # res.read()
    # print('cd done')

    # com3 = 
    # os.popen(com3)
    paraReplacer(webconfigPath, DsatPwd, EneityPwd)
    print('paraReplacer done')

    com4 = "cd " + DestinationfilePath + " && git add . && git commit -m 'deploy' && git push azure master"
    res = os.popen(com4)
    res.read()
    print('git chain done ' + com4)

    # com5 = "git commit -m 'deploy'"
    # res = os.popen(com5)
    # res.read()
    # print('git commit done')

    # com6 = "git push azure master"
    # res = os.popen(com6)
    # res.read()
    # print('git push done')

if __name__ == "__main__":
    main()
